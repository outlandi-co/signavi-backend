import express from "express"
import Order from "../models/Order.js"

const router = express.Router()

/* CREATE ORDER */

router.post("/", async (req,res)=>{

  try{

    const { items } = req.body

    const order = new Order({
      items
    })

    await order.save()

    res.json(order)

  }
  catch(err){

    res.status(500).json({error:err.message})

  }

})


/* GET ALL ORDERS */

router.get("/", async (req,res)=>{

  try{

    const orders = await Order.find().sort({createdAt:-1})

    res.json(orders)

  }
  catch(err){

    res.status(500).json({error:err.message})

  }

})

export default router