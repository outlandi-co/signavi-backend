import mongoose from "mongoose"

const productSchema = new mongoose.Schema({

  name: {
    type: String,
    required: true
  },

  brand: String,

  material: String,

  description: String,

  price: {
    type: Number,
    required: true
  },

  image: String,

  category: {
    type: String,
    enum: ["apparel","hats","dtf","laser","stickers"],
    default: "apparel"
  },

  variants: [
    {
      size: String,
      color: String,
      inventory: Number
    }
  ]

},{ timestamps:true })

export default mongoose.model("Product",productSchema)