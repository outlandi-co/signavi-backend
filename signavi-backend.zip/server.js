import express from "express"
import mongoose from "mongoose"
import cors from "cors"
import dotenv from "dotenv"
import cookieParser from "cookie-parser"

import productRoutes from "./routes/products.js"
import checkoutRoutes from "./routes/checkoutRoutes.js"
import orderRoutes from "./routes/orders.js"
import webhookRoutes from "./routes/webhookRoutes.js"
import authRoutes from "./routes/authRoutes.js"
import logoutRoutes from "./routes/logout.js"
import stripeRoutes from "./routes/stripe.js"

dotenv.config()

const app = express()

/* ------------------ CORS ------------------ */
app.use(cors({
  origin: "http://localhost:5173",
  credentials: true
}))

/* ------------------ Stripe Webhook ------------------ */
/* MUST be before express.json() */
app.use("/api/webhook", express.raw({ type: "application/json" }))
app.use("/api/webhook", webhookRoutes)

/* ------------------ Standard Middleware ------------------ */
app.use(express.json()) // Must be before Stripe routes to parse JSON properly
app.use(cookieParser())

/* ------------------ API Routes ------------------ */
app.use("/api/products", productRoutes)
app.use("/api/checkout", checkoutRoutes)
app.use("/api/orders", orderRoutes)
app.use("/api/auth", authRoutes)
app.use("/api/logout", logoutRoutes)

/* ------------------ Stripe Routes ------------------ */
app.use("/api/stripe", stripeRoutes)

/* ------------------ Health Check ------------------ */
app.get("/", (req, res) => {
  res.send("Signavi API is running")
})

/* ------------------ MongoDB + Server Start ------------------ */
async function startServer() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      dbName: "signavi_store"
    })
    console.log("MongoDB connected successfully")
    console.log("Mongo Host:", mongoose.connection.host)
    console.log("Database Name:", mongoose.connection.name)

    const PORT = process.env.PORT || 5050
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  } catch (error) {
    console.error("MongoDB connection error:", error)
    process.exit(1)
  }
}

/* ------------------ Mongo Error Listener ------------------ */
mongoose.connection.on("error", err => {
  console.error("MongoDB runtime error:", err)
})

startServer()