import express from "express"
import Product from "../models/Product.js"
import { requireAuth } from "../middleware/auth.js"

const router = express.Router()

/* ---------------- GET ALL PRODUCTS (PUBLIC) ---------------- */

router.get("/", async (req, res) => {

  try {

    const products = await Product.find().sort({ createdAt: -1 })

    return res.json(products)

  } catch (err) {

    console.error("GET PRODUCTS ERROR:", err)

    return res.status(500).json({
      error: err.message
    })

  }

})


/* ---------------- GET SINGLE PRODUCT (PUBLIC) ---------------- */

router.get("/:id", async (req, res) => {

  try {

    const product = await Product.findById(req.params.id)

    if (!product) {
      return res.status(404).json({
        error: "Product not found"
      })
    }

    return res.json(product)

  } catch (err) {

    console.error("GET PRODUCT ERROR:", err)

    return res.status(500).json({
      error: err.message
    })

  }

})


/* ---------------- CREATE PRODUCT (ADMIN ONLY) ---------------- */

router.post("/", requireAuth, async (req, res) => {

  if (req.user.role !== "admin") {
    return res.status(403).json({
      error: "Admin access required"
    })
  }

  try {

    console.log("CREATE PRODUCT BODY:", req.body)

    const product = new Product(req.body)

    const savedProduct = await product.save()

    return res.status(201).json(savedProduct)

  } catch (err) {

    console.error("CREATE PRODUCT ERROR:", err)

    return res.status(500).json({
      error: err.message
    })

  }

})


/* ---------------- UPDATE PRODUCT (ADMIN ONLY) ---------------- */

router.put("/:id", requireAuth, async (req, res) => {

  if (req.user.role !== "admin") {
    return res.status(403).json({
      error: "Admin access required"
    })
  }

  try {

    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    )

    if (!updatedProduct) {
      return res.status(404).json({
        error: "Product not found"
      })
    }

    return res.json(updatedProduct)

  } catch (err) {

    console.error("UPDATE PRODUCT ERROR:", err)

    return res.status(500).json({
      error: err.message
    })

  }

})


/* ---------------- DELETE PRODUCT (ADMIN ONLY) ---------------- */

router.delete("/:id", requireAuth, async (req, res) => {

  if (req.user.role !== "admin") {
    return res.status(403).json({
      error: "Admin access required"
    })
  }

  try {

    const deletedProduct = await Product.findByIdAndDelete(req.params.id)

    if (!deletedProduct) {
      return res.status(404).json({
        error: "Product not found"
      })
    }

    return res.json({
      message: "Product deleted successfully"
    })

  } catch (err) {

    console.error("DELETE PRODUCT ERROR:", err)

    return res.status(500).json({
      error: err.message
    })

  }

})

export default router