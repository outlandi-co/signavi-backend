import express from "express"
import Order from "../models/Order.js"

const router = express.Router()

/* GET ORDERS */

router.get("/", async (req, res) => {

  try {

    const orders = await Order.find().sort({ createdAt: -1 })

    res.json(orders)

  } catch (error) {

    res.status(500).json({ error: "Failed to fetch orders" })

  }

})

/* CREATE ORDER */

router.post("/", async (req, res) => {

  console.log("ORDER BODY:", req.body)

  try {

    const newOrder = new Order(req.body)

    const savedOrder = await newOrder.save()

    res.status(201).json(savedOrder)

  } catch (error) {

    console.error(error)

    res.status(500).json({ error: "Failed to create order" })

  }

})

export default router